package com.sym.ams.dao;

import com.sym.ams.dao.base.BaseDao;
import com.sym.ams.domain.AmsOperatorChannel;
import com.sym.ams.domain.AmsOperatorChannelCriteria;
 
/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
public interface AmsOperatorChannelDao extends BaseDao<AmsOperatorChannel, AmsOperatorChannelCriteria, String> {
}

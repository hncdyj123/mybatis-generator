package com.sym.ams.domain;

import java.io.Serializable;
import java.util.Date;

public class AmsOperatorOriginality implements Serializable {
    //����
    private String id;

    //����ID
    private String originalityId;

    //��������
    private String originalityDesc;

    //�����ʶ
    private Boolean paintFlag;

    //������
    private String operator;

    //�Ƿ�ͣ��(0 ��  1 ��)
    private Boolean isDown;

    //������
    private String createName;

    //����ʱ��
    private Date createDatetime;

    //�޸���
    private String updateName;

    //�޸�ʱ��
    private Date updateDatetime;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getOriginalityId() {
        return originalityId;
    }

    public void setOriginalityId(String originalityId) {
        this.originalityId = originalityId == null ? null : originalityId.trim();
    }

    public String getOriginalityDesc() {
        return originalityDesc;
    }

    public void setOriginalityDesc(String originalityDesc) {
        this.originalityDesc = originalityDesc == null ? null : originalityDesc.trim();
    }

    public Boolean getPaintFlag() {
        return paintFlag;
    }

    public void setPaintFlag(Boolean paintFlag) {
        this.paintFlag = paintFlag;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    public Boolean getIsDown() {
        return isDown;
    }

    public void setIsDown(Boolean isDown) {
        this.isDown = isDown;
    }

    public String getCreateName() {
        return createName;
    }

    public void setCreateName(String createName) {
        this.createName = createName == null ? null : createName.trim();
    }

    public Date getCreateDatetime() {
        return createDatetime;
    }

    public void setCreateDatetime(Date createDatetime) {
        this.createDatetime = createDatetime;
    }

    public String getUpdateName() {
        return updateName;
    }

    public void setUpdateName(String updateName) {
        this.updateName = updateName == null ? null : updateName.trim();
    }

    public Date getUpdateDatetime() {
        return updateDatetime;
    }

    public void setUpdateDatetime(Date updateDatetime) {
        this.updateDatetime = updateDatetime;
    }
}
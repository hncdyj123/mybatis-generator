package com.sym.ams.dao;

import com.sym.ams.dao.base.BaseDao;
import com.sym.ams.domain.AmsOperatorActivity;
import com.sym.ams.domain.AmsOperatorActivityCriteria;
 
/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
public interface AmsOperatorActivityDao extends BaseDao<AmsOperatorActivity, AmsOperatorActivityCriteria, String> {
}

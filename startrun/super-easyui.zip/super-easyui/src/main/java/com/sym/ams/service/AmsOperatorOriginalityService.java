package com.sym.ams.service;

import java.util.List;

import com.sym.ams.domain.base.*;
import java.util.List;
import java.util.Map;
import com.sym.ams.domain.AmsOperatorOriginality;

/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
public interface AmsOperatorOriginalityService {
	/**新增对象 组装为空字段**/
	public int insertAmsOperatorOriginality(AmsOperatorOriginality amsOperatorOriginality);

	/**新增对象 不组装为空字段**/
	public int insertAmsOperatorOriginalitySelective(AmsOperatorOriginality amsOperatorOriginality);

	/**删除对象 不组装为空字段**/
	public int deleteAmsOperatorOriginalityByCriteria(AmsOperatorOriginality amsOperatorOriginality);

	/**删除对象 根据主键删除**/
	public int deleteAmsOperatorOriginalityByPrimaryKey(String primaryId);

	/**修改对象 不组装为空字段 参数一:组装条件Object 参数二:修改Object**/
	public int updateAmsOperatorOriginalityByCriteriaSelective(AmsOperatorOriginality amsOperatorOriginality1, AmsOperatorOriginality amsOperatorOriginality2);

	/**修改对象 根据主键修改**/
	public int updateAmsOperatorOriginalityByPrimaryKeySelective(AmsOperatorOriginality amsOperatorOriginality);
	
	/** 翻页查询 **/
	public DataGrid queryAmsOperatorOriginalityByPage(AmsOperatorOriginality amsOperatorOriginality);
	
	/**查询对象 根据主键查询**/
	public AmsOperatorOriginality selectAmsOperatorOriginalityByPrimaryKey(String primaryId);

	/**查询对象 根据对象查询**/
	public AmsOperatorOriginality selectAmsOperatorOriginality(AmsOperatorOriginality amsOperatorOriginality);
	
	/**查询对象 根据对象查询**/
	public List<AmsOperatorOriginality> selectAmsOperatorOriginalityList(AmsOperatorOriginality amsOperatorOriginality);
}

package com.sym.ams.domain;

import java.io.Serializable;
import java.util.Date;

public class AmsOperatorChannel implements Serializable {
    //����
    private String id;

    //����ID
    private String channelId;

    //��������
    private String chineseDesc;

    //������ID
    private String supplierId;

    //����������
    private String groupName;

    //������ʶ(0  ������  1 ����)
    private Boolean throwFlag;

    //�����ʶ(0 ���ɿ� 1 �ɿ�)
    private Boolean paintFlag;

    //�Ƿ�ͣ��(0 ��  1 ��)
    private Boolean isDown;

    //������
    private String createName;

    //����ʱ��
    private Date createDatetime;

    //�޸���
    private String updateName;

    //�޸�ʱ��
    private Date updateDatetime;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId == null ? null : channelId.trim();
    }

    public String getChineseDesc() {
        return chineseDesc;
    }

    public void setChineseDesc(String chineseDesc) {
        this.chineseDesc = chineseDesc == null ? null : chineseDesc.trim();
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId == null ? null : supplierId.trim();
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName == null ? null : groupName.trim();
    }

    public Boolean getThrowFlag() {
        return throwFlag;
    }

    public void setThrowFlag(Boolean throwFlag) {
        this.throwFlag = throwFlag;
    }

    public Boolean getPaintFlag() {
        return paintFlag;
    }

    public void setPaintFlag(Boolean paintFlag) {
        this.paintFlag = paintFlag;
    }

    public Boolean getIsDown() {
        return isDown;
    }

    public void setIsDown(Boolean isDown) {
        this.isDown = isDown;
    }

    public String getCreateName() {
        return createName;
    }

    public void setCreateName(String createName) {
        this.createName = createName == null ? null : createName.trim();
    }

    public Date getCreateDatetime() {
        return createDatetime;
    }

    public void setCreateDatetime(Date createDatetime) {
        this.createDatetime = createDatetime;
    }

    public String getUpdateName() {
        return updateName;
    }

    public void setUpdateName(String updateName) {
        this.updateName = updateName == null ? null : updateName.trim();
    }

    public Date getUpdateDatetime() {
        return updateDatetime;
    }

    public void setUpdateDatetime(Date updateDatetime) {
        this.updateDatetime = updateDatetime;
    }
}
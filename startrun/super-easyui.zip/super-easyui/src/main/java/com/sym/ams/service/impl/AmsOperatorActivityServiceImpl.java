package com.sym.ams.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.sym.ams.domain.base.*;
import com.sym.ams.domain.AmsOperatorActivity;
import com.sym.ams.inner.InnerAmsOperatorActivityService;
import com.sym.ams.service.AmsOperatorActivityService;

/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
 @Service
 @Transactional
public class AmsOperatorActivityServiceImpl implements AmsOperatorActivityService {
	@Resource
	private InnerAmsOperatorActivityService innerAmsOperatorActivityService;
	
	@Override
	/**新增对象 组装为空字段**/
	public int insertAmsOperatorActivity(AmsOperatorActivity amsOperatorActivity) {
		return innerAmsOperatorActivityService.insertAmsOperatorActivity(amsOperatorActivity);
	}
	
	@Override
	/**新增对象 不组装为空字段**/
	public int insertAmsOperatorActivitySelective(AmsOperatorActivity amsOperatorActivity) {
		return innerAmsOperatorActivityService.insertAmsOperatorActivitySelective(amsOperatorActivity);
	}

	@Override
	/**删除对象 不组装为空字段**/
	public int deleteAmsOperatorActivityByCriteria(AmsOperatorActivity amsOperatorActivity) {
		return innerAmsOperatorActivityService.deleteAmsOperatorActivityByCriteria(amsOperatorActivity);
	}
	
	@Override
	/**删除对象 根据主键删除**/
	public int deleteAmsOperatorActivityByPrimaryKey(String primaryId) {
		return innerAmsOperatorActivityService.deleteAmsOperatorActivityByPrimaryKey(primaryId);
	}

	@Override
	/**修改对象 不组装为空字段 参数一:组装条件Object 参数二:修改Object**/
	public int updateAmsOperatorActivityByCriteriaSelective(AmsOperatorActivity amsOperatorActivity1, AmsOperatorActivity amsOperatorActivity2) {
		return innerAmsOperatorActivityService.updateAmsOperatorActivityByCriteriaSelective(amsOperatorActivity1,amsOperatorActivity2);
	}
	
	@Override
	/**修改对象 根据主键修改**/
	public int updateAmsOperatorActivityByPrimaryKeySelective(AmsOperatorActivity amsOperatorActivity) {
		return innerAmsOperatorActivityService.updateAmsOperatorActivityByPrimaryKeySelective(amsOperatorActivity);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public DataGrid queryAmsOperatorActivityByPage(AmsOperatorActivity amsOperatorActivity) {
		int total = innerAmsOperatorActivityService.countAmsOperatorActivityByCriteria(amsOperatorActivity);
		List<AmsOperatorActivity> amsOperatorActivityList = innerAmsOperatorActivityService.selectAmsOperatorActivityList(amsOperatorActivity);
		return new DataGrid(total,amsOperatorActivityList);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public AmsOperatorActivity selectAmsOperatorActivityByPrimaryKey(String primaryId) {
		return innerAmsOperatorActivityService.selectAmsOperatorActivityByPrimaryKey(primaryId);
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public AmsOperatorActivity selectAmsOperatorActivity(AmsOperatorActivity amsOperatorActivity){
		return innerAmsOperatorActivityService.selectAmsOperatorActivity(amsOperatorActivity);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public List<AmsOperatorActivity> selectAmsOperatorActivityList(AmsOperatorActivity amsOperatorActivity) {
		return innerAmsOperatorActivityService.selectAmsOperatorActivityList(amsOperatorActivity);
	}
}

package com.sym.ams.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.sym.ams.domain.base.*;
import com.sym.ams.domain.AmsOperatorChannel;
import com.sym.ams.inner.InnerAmsOperatorChannelService;
import com.sym.ams.service.AmsOperatorChannelService;

/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
 @Service
 @Transactional
public class AmsOperatorChannelServiceImpl implements AmsOperatorChannelService {
	@Resource
	private InnerAmsOperatorChannelService innerAmsOperatorChannelService;
	
	@Override
	/**新增对象 组装为空字段**/
	public int insertAmsOperatorChannel(AmsOperatorChannel amsOperatorChannel) {
		return innerAmsOperatorChannelService.insertAmsOperatorChannel(amsOperatorChannel);
	}
	
	@Override
	/**新增对象 不组装为空字段**/
	public int insertAmsOperatorChannelSelective(AmsOperatorChannel amsOperatorChannel) {
		return innerAmsOperatorChannelService.insertAmsOperatorChannelSelective(amsOperatorChannel);
	}

	@Override
	/**删除对象 不组装为空字段**/
	public int deleteAmsOperatorChannelByCriteria(AmsOperatorChannel amsOperatorChannel) {
		return innerAmsOperatorChannelService.deleteAmsOperatorChannelByCriteria(amsOperatorChannel);
	}
	
	@Override
	/**删除对象 根据主键删除**/
	public int deleteAmsOperatorChannelByPrimaryKey(String primaryId) {
		return innerAmsOperatorChannelService.deleteAmsOperatorChannelByPrimaryKey(primaryId);
	}

	@Override
	/**修改对象 不组装为空字段 参数一:组装条件Object 参数二:修改Object**/
	public int updateAmsOperatorChannelByCriteriaSelective(AmsOperatorChannel amsOperatorChannel1, AmsOperatorChannel amsOperatorChannel2) {
		return innerAmsOperatorChannelService.updateAmsOperatorChannelByCriteriaSelective(amsOperatorChannel1,amsOperatorChannel2);
	}
	
	@Override
	/**修改对象 根据主键修改**/
	public int updateAmsOperatorChannelByPrimaryKeySelective(AmsOperatorChannel amsOperatorChannel) {
		return innerAmsOperatorChannelService.updateAmsOperatorChannelByPrimaryKeySelective(amsOperatorChannel);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public DataGrid queryAmsOperatorChannelByPage(AmsOperatorChannel amsOperatorChannel) {
		int total = innerAmsOperatorChannelService.countAmsOperatorChannelByCriteria(amsOperatorChannel);
		List<AmsOperatorChannel> amsOperatorChannelList = innerAmsOperatorChannelService.selectAmsOperatorChannelList(amsOperatorChannel);
		return new DataGrid(total,amsOperatorChannelList);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public AmsOperatorChannel selectAmsOperatorChannelByPrimaryKey(String primaryId) {
		return innerAmsOperatorChannelService.selectAmsOperatorChannelByPrimaryKey(primaryId);
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public AmsOperatorChannel selectAmsOperatorChannel(AmsOperatorChannel amsOperatorChannel){
		return innerAmsOperatorChannelService.selectAmsOperatorChannel(amsOperatorChannel);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public List<AmsOperatorChannel> selectAmsOperatorChannelList(AmsOperatorChannel amsOperatorChannel) {
		return innerAmsOperatorChannelService.selectAmsOperatorChannelList(amsOperatorChannel);
	}
}

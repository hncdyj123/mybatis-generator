package com.sym.ams.inner.impl;

import java.lang.String;
import java.lang.Boolean;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.sym.ams.domain.AmsOperatorChannelCriteria;
import com.sym.ams.domain.AmsOperatorChannelCriteria.Criteria;

import com.sym.ams.domain.AmsOperatorChannel;
import com.sym.ams.dao.AmsOperatorChannelDao;
import com.sym.ams.inner.InnerAmsOperatorChannelService;

/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
@Service
public class InnerAmsOperatorChannelServiceImpl implements InnerAmsOperatorChannelService {

	@Resource
	private AmsOperatorChannelDao amsOperatorChannelDao;
	
	@Override
	public int insertAmsOperatorChannel(AmsOperatorChannel amsOperatorChannel) {
		return amsOperatorChannelDao.insert(amsOperatorChannel);
	}

	@Override
	public int insertAmsOperatorChannelSelective(AmsOperatorChannel amsOperatorChannel) {
		return amsOperatorChannelDao.insertSelective(amsOperatorChannel);
	}
	
	@Override
	public int deleteAmsOperatorChannelByCriteria(AmsOperatorChannel amsOperatorChannel) {
		AmsOperatorChannelCriteria criteria = this.createCriteria(amsOperatorChannel);
		return amsOperatorChannelDao.deleteByCriteria(criteria);
	}
	
	@Override
	public int deleteAmsOperatorChannelByPrimaryKey(String primaryId) {
		return amsOperatorChannelDao.deleteByPrimaryKey(primaryId);
	}

	@Override
	public int updateAmsOperatorChannelByCriteriaSelective(AmsOperatorChannel amsOperatorChannel1, AmsOperatorChannel amsOperatorChannel2) {
		AmsOperatorChannelCriteria criteria = this.createCriteria(amsOperatorChannel1);
		return amsOperatorChannelDao.updateByCriteriaSelective(amsOperatorChannel2,criteria);
	}
	
	@Override
	public int updateAmsOperatorChannelByPrimaryKeySelective(AmsOperatorChannel amsOperatorChannel) {
		return amsOperatorChannelDao.updateByPrimaryKeySelective(amsOperatorChannel);
	}
	
	@Override
	public int countAmsOperatorChannelByCriteria(AmsOperatorChannel amsOperatorChannel) {
		AmsOperatorChannelCriteria criteria = this.createCriteria(amsOperatorChannel);
		return amsOperatorChannelDao.countByCriteria(criteria);
	}

	@Override
	public AmsOperatorChannel selectAmsOperatorChannelByPrimaryKey(String primaryId) {
		return amsOperatorChannelDao.selectByPrimaryKey(primaryId);
	}

	@Override
	public AmsOperatorChannel selectAmsOperatorChannel(AmsOperatorChannel amsOperatorChannel) {
		AmsOperatorChannelCriteria criteria = this.createCriteria(amsOperatorChannel);
		List<AmsOperatorChannel> amsOperatorChannelList = amsOperatorChannelDao.selectByCriteria(criteria);
		if (CollectionUtils.isNotEmpty(amsOperatorChannelList)) {
			return amsOperatorChannelList.get(0);
		}
		return null;
	}
	
	@Override
	public AmsOperatorChannel selectAmsOperatorChannel(Map<String,Object> paramMap) {
		AmsOperatorChannelCriteria criteria = this.createCriteria(paramMap);
		List<AmsOperatorChannel> amsOperatorChannelList = amsOperatorChannelDao.selectByCriteria(criteria);
		if (CollectionUtils.isNotEmpty(amsOperatorChannelList)) {
			return amsOperatorChannelList.get(0);
		}
		return null;
	}
	
	@Override
	public List<AmsOperatorChannel> selectAmsOperatorChannelList(AmsOperatorChannel amsOperatorChannel) {
		AmsOperatorChannelCriteria criteria = this.createCriteria(amsOperatorChannel);
		List<AmsOperatorChannel> amsOperatorChannelList = amsOperatorChannelDao.selectByCriteria(criteria);
		return amsOperatorChannelList;
	}
	
	@Override
	public List<AmsOperatorChannel> selectAmsOperatorChannelList(Map<String,Object> paramMap) {
		AmsOperatorChannelCriteria criteria = this.createCriteria(paramMap);
		List<AmsOperatorChannel> amsOperatorChannelList = amsOperatorChannelDao.selectByCriteria(criteria);
		return amsOperatorChannelList;
	}
	
	private AmsOperatorChannelCriteria createCriteria(AmsOperatorChannel amsOperatorChannel) {
		AmsOperatorChannelCriteria criteria = new AmsOperatorChannelCriteria();
		Criteria c = criteria.createCriteria();
		if (amsOperatorChannel != null) {
			if (amsOperatorChannel.getId() != null) {
				c.andIdEqualTo(amsOperatorChannel.getId());
			}	
			if (amsOperatorChannel.getChannelId() != null) {
				c.andChannelIdEqualTo(amsOperatorChannel.getChannelId());
			}	
			if (amsOperatorChannel.getChineseDesc() != null) {
				c.andChineseDescEqualTo(amsOperatorChannel.getChineseDesc());
			}	
			if (amsOperatorChannel.getSupplierId() != null) {
				c.andSupplierIdEqualTo(amsOperatorChannel.getSupplierId());
			}	
			if (amsOperatorChannel.getGroupName() != null) {
				c.andGroupNameEqualTo(amsOperatorChannel.getGroupName());
			}	
			if (amsOperatorChannel.getThrowFlag() != null) {
				c.andThrowFlagEqualTo(amsOperatorChannel.getThrowFlag());
			}	
			if (amsOperatorChannel.getPaintFlag() != null) {
				c.andPaintFlagEqualTo(amsOperatorChannel.getPaintFlag());
			}	
			if (amsOperatorChannel.getIsDown() != null) {
				c.andIsDownEqualTo(amsOperatorChannel.getIsDown());
			}	
			if (amsOperatorChannel.getCreateName() != null) {
				c.andCreateNameEqualTo(amsOperatorChannel.getCreateName());
			}	
			if (amsOperatorChannel.getCreateDatetime() != null) {
				c.andCreateDatetimeEqualTo(amsOperatorChannel.getCreateDatetime());
			}	
			if (amsOperatorChannel.getUpdateName() != null) {
				c.andUpdateNameEqualTo(amsOperatorChannel.getUpdateName());
			}	
			if (amsOperatorChannel.getUpdateDatetime() != null) {
				c.andUpdateDatetimeEqualTo(amsOperatorChannel.getUpdateDatetime());
			}	
		}
		return criteria;
	}
	
	private AmsOperatorChannelCriteria createCriteria(Map<String, Object> paramMap) {
		AmsOperatorChannelCriteria criteria = new AmsOperatorChannelCriteria();
		Criteria c = criteria.createCriteria();
		if (paramMap != null) {
			if (paramMap.get("id") != null) {
				c.andIdEqualTo((String) paramMap.get("id"));
			}
			if (paramMap.get("channelId") != null) {
				c.andChannelIdEqualTo((String) paramMap.get("channelId"));
			}
			if (paramMap.get("chineseDesc") != null) {
				c.andChineseDescEqualTo((String) paramMap.get("chineseDesc"));
			}
			if (paramMap.get("supplierId") != null) {
				c.andSupplierIdEqualTo((String) paramMap.get("supplierId"));
			}
			if (paramMap.get("groupName") != null) {
				c.andGroupNameEqualTo((String) paramMap.get("groupName"));
			}
			if (paramMap.get("throwFlag") != null) {
				c.andThrowFlagEqualTo((Boolean) paramMap.get("throwFlag"));
			}
			if (paramMap.get("paintFlag") != null) {
				c.andPaintFlagEqualTo((Boolean) paramMap.get("paintFlag"));
			}
			if (paramMap.get("isDown") != null) {
				c.andIsDownEqualTo((Boolean) paramMap.get("isDown"));
			}
			if (paramMap.get("createName") != null) {
				c.andCreateNameEqualTo((String) paramMap.get("createName"));
			}
			if (paramMap.get("createDatetime") != null) {
				c.andCreateDatetimeEqualTo((Timestamp) paramMap.get("createDatetime"));
			}
			if (paramMap.get("updateName") != null) {
				c.andUpdateNameEqualTo((String) paramMap.get("updateName"));
			}
			if (paramMap.get("updateDatetime") != null) {
				c.andUpdateDatetimeEqualTo((Timestamp) paramMap.get("updateDatetime"));
			}
		}
		return criteria;
	}
}

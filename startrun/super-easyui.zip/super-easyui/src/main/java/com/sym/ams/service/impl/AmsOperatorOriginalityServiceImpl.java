package com.sym.ams.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.sym.ams.domain.base.*;
import com.sym.ams.domain.AmsOperatorOriginality;
import com.sym.ams.inner.InnerAmsOperatorOriginalityService;
import com.sym.ams.service.AmsOperatorOriginalityService;

/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
 @Service
 @Transactional
public class AmsOperatorOriginalityServiceImpl implements AmsOperatorOriginalityService {
	@Resource
	private InnerAmsOperatorOriginalityService innerAmsOperatorOriginalityService;
	
	@Override
	/**新增对象 组装为空字段**/
	public int insertAmsOperatorOriginality(AmsOperatorOriginality amsOperatorOriginality) {
		return innerAmsOperatorOriginalityService.insertAmsOperatorOriginality(amsOperatorOriginality);
	}
	
	@Override
	/**新增对象 不组装为空字段**/
	public int insertAmsOperatorOriginalitySelective(AmsOperatorOriginality amsOperatorOriginality) {
		return innerAmsOperatorOriginalityService.insertAmsOperatorOriginalitySelective(amsOperatorOriginality);
	}

	@Override
	/**删除对象 不组装为空字段**/
	public int deleteAmsOperatorOriginalityByCriteria(AmsOperatorOriginality amsOperatorOriginality) {
		return innerAmsOperatorOriginalityService.deleteAmsOperatorOriginalityByCriteria(amsOperatorOriginality);
	}
	
	@Override
	/**删除对象 根据主键删除**/
	public int deleteAmsOperatorOriginalityByPrimaryKey(String primaryId) {
		return innerAmsOperatorOriginalityService.deleteAmsOperatorOriginalityByPrimaryKey(primaryId);
	}

	@Override
	/**修改对象 不组装为空字段 参数一:组装条件Object 参数二:修改Object**/
	public int updateAmsOperatorOriginalityByCriteriaSelective(AmsOperatorOriginality amsOperatorOriginality1, AmsOperatorOriginality amsOperatorOriginality2) {
		return innerAmsOperatorOriginalityService.updateAmsOperatorOriginalityByCriteriaSelective(amsOperatorOriginality1,amsOperatorOriginality2);
	}
	
	@Override
	/**修改对象 根据主键修改**/
	public int updateAmsOperatorOriginalityByPrimaryKeySelective(AmsOperatorOriginality amsOperatorOriginality) {
		return innerAmsOperatorOriginalityService.updateAmsOperatorOriginalityByPrimaryKeySelective(amsOperatorOriginality);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public DataGrid queryAmsOperatorOriginalityByPage(AmsOperatorOriginality amsOperatorOriginality) {
		int total = innerAmsOperatorOriginalityService.countAmsOperatorOriginalityByCriteria(amsOperatorOriginality);
		List<AmsOperatorOriginality> amsOperatorOriginalityList = innerAmsOperatorOriginalityService.selectAmsOperatorOriginalityList(amsOperatorOriginality);
		return new DataGrid(total,amsOperatorOriginalityList);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public AmsOperatorOriginality selectAmsOperatorOriginalityByPrimaryKey(String primaryId) {
		return innerAmsOperatorOriginalityService.selectAmsOperatorOriginalityByPrimaryKey(primaryId);
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public AmsOperatorOriginality selectAmsOperatorOriginality(AmsOperatorOriginality amsOperatorOriginality){
		return innerAmsOperatorOriginalityService.selectAmsOperatorOriginality(amsOperatorOriginality);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	@Override
	public List<AmsOperatorOriginality> selectAmsOperatorOriginalityList(AmsOperatorOriginality amsOperatorOriginality) {
		return innerAmsOperatorOriginalityService.selectAmsOperatorOriginalityList(amsOperatorOriginality);
	}
}

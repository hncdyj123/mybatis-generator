package com.sym.ams.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sym.ams.domain.base.*;
import com.sym.ams.domain.AmsOperatorActivity;
import com.sym.ams.service.AmsOperatorActivityService;

@Controller
@RequestMapping("/amsOperatorActivity")
public class AmsOperatorActivityController {
	private static Logger LOGGER = LoggerFactory.getLogger(AmsOperatorActivity.class);
	@Resource
	private AmsOperatorActivityService amsOperatorActivityService;

	@RequestMapping(value = "init")
	public ModelAndView init(HttpServletRequest request) {
		ModelAndView model = new ModelAndView();
		model.setViewName("/amsOperatorActivity");
		return model;
	}

	@RequestMapping(value = "getDataGrid", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object getDataGrid(AmsOperatorActivity amsOperatorActivity) {
		DataGrid dataGrid = new DataGrid();
		try {
			dataGrid = amsOperatorActivityService.queryAmsOperatorActivityByPage(amsOperatorActivity);
		} catch (Exception e) {
			LOGGER.error("getDataGrid method error : " + e);
			dataGrid.setCode(500);
			dataGrid.setMessage("getDataGrid error!");
		}
		return dataGrid;
	}

	@RequestMapping(value = "insert", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object insert(AmsOperatorActivity amsOperatorActivity) {
		Message message = new Message();
		try {
			amsOperatorActivityService.insertAmsOperatorActivitySelective(amsOperatorActivity);
		} catch (Exception e) {
			LOGGER.error("insert method error :", e);
			message.setCode(500);
			message.setMessage("insert error!");
		}
		return message;
	}
	
	@RequestMapping(value = "delete", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object delete(AmsOperatorActivity amsOperatorActivity) {
		Message message = new Message();
		try {
			amsOperatorActivityService.deleteAmsOperatorActivityByPrimaryKey(amsOperatorActivity.getId());
		} catch (Exception e) {
			LOGGER.error("delete method error :", e);
			message.setCode(500);
			message.setMessage("delete error!");
		}
		return message;
	}

	@RequestMapping(value = "update", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object update(AmsOperatorActivity amsOperatorActivity) {
		Message message = new Message();
		try {
			amsOperatorActivityService.updateAmsOperatorActivityByPrimaryKeySelective(amsOperatorActivity);
		} catch (Exception e) {
			LOGGER.error("update method error :", e);
			message.setCode(500);
			message.setMessage("update error!");
		}
		return message;
	}

	@RequestMapping(value = "query", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object query(AmsOperatorActivity amsOperatorActivity) {
		Message message = new Message();
		try {
			message.setResult(amsOperatorActivityService.selectAmsOperatorActivityList(amsOperatorActivity));
		} catch (Exception e) {
			LOGGER.error("query method error :", e);
			message.setCode(500);
			message.setMessage("query error!");
		}
		return message;
	}
	
	@RequestMapping(value = "queryById", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object queryById(AmsOperatorActivity amsOperatorActivity) {
		Message message = new Message();
		try {
			message.setResult(amsOperatorActivityService.selectAmsOperatorActivityByPrimaryKey(amsOperatorActivity.getId()));
		} catch (Exception e) {
			LOGGER.error("queryById method error :", e);
			message.setCode(500);
			message.setMessage("queryById error!");
		}
		return message;
	}
	
	@RequestMapping(value = "queryByCondition", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object queryByCondition(AmsOperatorActivity amsOperatorActivity) {
		Message message = new Message();
		try {
			message.setResult(amsOperatorActivityService.selectAmsOperatorActivityList(amsOperatorActivity));
		} catch (Exception e) {
			LOGGER.error("queryByCondition method error :", e);
			message.setCode(500);
			message.setMessage("queryByCondition error!");
		}
		return message;
	}

}

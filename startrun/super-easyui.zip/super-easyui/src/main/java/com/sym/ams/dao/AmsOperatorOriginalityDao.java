package com.sym.ams.dao;

import com.sym.ams.dao.base.BaseDao;
import com.sym.ams.domain.AmsOperatorOriginality;
import com.sym.ams.domain.AmsOperatorOriginalityCriteria;
 
/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
public interface AmsOperatorOriginalityDao extends BaseDao<AmsOperatorOriginality, AmsOperatorOriginalityCriteria, String> {
}

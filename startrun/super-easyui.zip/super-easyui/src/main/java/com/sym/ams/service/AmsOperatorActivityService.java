package com.sym.ams.service;

import java.util.List;

import com.sym.ams.domain.base.*;
import java.util.List;
import java.util.Map;
import com.sym.ams.domain.AmsOperatorActivity;

/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
public interface AmsOperatorActivityService {
	/**新增对象 组装为空字段**/
	public int insertAmsOperatorActivity(AmsOperatorActivity amsOperatorActivity);

	/**新增对象 不组装为空字段**/
	public int insertAmsOperatorActivitySelective(AmsOperatorActivity amsOperatorActivity);

	/**删除对象 不组装为空字段**/
	public int deleteAmsOperatorActivityByCriteria(AmsOperatorActivity amsOperatorActivity);

	/**删除对象 根据主键删除**/
	public int deleteAmsOperatorActivityByPrimaryKey(String primaryId);

	/**修改对象 不组装为空字段 参数一:组装条件Object 参数二:修改Object**/
	public int updateAmsOperatorActivityByCriteriaSelective(AmsOperatorActivity amsOperatorActivity1, AmsOperatorActivity amsOperatorActivity2);

	/**修改对象 根据主键修改**/
	public int updateAmsOperatorActivityByPrimaryKeySelective(AmsOperatorActivity amsOperatorActivity);
	
	/** 翻页查询 **/
	public DataGrid queryAmsOperatorActivityByPage(AmsOperatorActivity amsOperatorActivity);
	
	/**查询对象 根据主键查询**/
	public AmsOperatorActivity selectAmsOperatorActivityByPrimaryKey(String primaryId);

	/**查询对象 根据对象查询**/
	public AmsOperatorActivity selectAmsOperatorActivity(AmsOperatorActivity amsOperatorActivity);
	
	/**查询对象 根据对象查询**/
	public List<AmsOperatorActivity> selectAmsOperatorActivityList(AmsOperatorActivity amsOperatorActivity);
}

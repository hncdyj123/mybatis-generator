package com.sym.ams.inner.impl;

import java.lang.String;
import java.lang.Boolean;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.sym.ams.domain.AmsOperatorActivityCriteria;
import com.sym.ams.domain.AmsOperatorActivityCriteria.Criteria;

import com.sym.ams.domain.AmsOperatorActivity;
import com.sym.ams.dao.AmsOperatorActivityDao;
import com.sym.ams.inner.InnerAmsOperatorActivityService;

/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
@Service
public class InnerAmsOperatorActivityServiceImpl implements InnerAmsOperatorActivityService {

	@Resource
	private AmsOperatorActivityDao amsOperatorActivityDao;
	
	@Override
	public int insertAmsOperatorActivity(AmsOperatorActivity amsOperatorActivity) {
		return amsOperatorActivityDao.insert(amsOperatorActivity);
	}

	@Override
	public int insertAmsOperatorActivitySelective(AmsOperatorActivity amsOperatorActivity) {
		return amsOperatorActivityDao.insertSelective(amsOperatorActivity);
	}
	
	@Override
	public int deleteAmsOperatorActivityByCriteria(AmsOperatorActivity amsOperatorActivity) {
		AmsOperatorActivityCriteria criteria = this.createCriteria(amsOperatorActivity);
		return amsOperatorActivityDao.deleteByCriteria(criteria);
	}
	
	@Override
	public int deleteAmsOperatorActivityByPrimaryKey(String primaryId) {
		return amsOperatorActivityDao.deleteByPrimaryKey(primaryId);
	}

	@Override
	public int updateAmsOperatorActivityByCriteriaSelective(AmsOperatorActivity amsOperatorActivity1, AmsOperatorActivity amsOperatorActivity2) {
		AmsOperatorActivityCriteria criteria = this.createCriteria(amsOperatorActivity1);
		return amsOperatorActivityDao.updateByCriteriaSelective(amsOperatorActivity2,criteria);
	}
	
	@Override
	public int updateAmsOperatorActivityByPrimaryKeySelective(AmsOperatorActivity amsOperatorActivity) {
		return amsOperatorActivityDao.updateByPrimaryKeySelective(amsOperatorActivity);
	}
	
	@Override
	public int countAmsOperatorActivityByCriteria(AmsOperatorActivity amsOperatorActivity) {
		AmsOperatorActivityCriteria criteria = this.createCriteria(amsOperatorActivity);
		return amsOperatorActivityDao.countByCriteria(criteria);
	}

	@Override
	public AmsOperatorActivity selectAmsOperatorActivityByPrimaryKey(String primaryId) {
		return amsOperatorActivityDao.selectByPrimaryKey(primaryId);
	}

	@Override
	public AmsOperatorActivity selectAmsOperatorActivity(AmsOperatorActivity amsOperatorActivity) {
		AmsOperatorActivityCriteria criteria = this.createCriteria(amsOperatorActivity);
		List<AmsOperatorActivity> amsOperatorActivityList = amsOperatorActivityDao.selectByCriteria(criteria);
		if (CollectionUtils.isNotEmpty(amsOperatorActivityList)) {
			return amsOperatorActivityList.get(0);
		}
		return null;
	}
	
	@Override
	public AmsOperatorActivity selectAmsOperatorActivity(Map<String,Object> paramMap) {
		AmsOperatorActivityCriteria criteria = this.createCriteria(paramMap);
		List<AmsOperatorActivity> amsOperatorActivityList = amsOperatorActivityDao.selectByCriteria(criteria);
		if (CollectionUtils.isNotEmpty(amsOperatorActivityList)) {
			return amsOperatorActivityList.get(0);
		}
		return null;
	}
	
	@Override
	public List<AmsOperatorActivity> selectAmsOperatorActivityList(AmsOperatorActivity amsOperatorActivity) {
		AmsOperatorActivityCriteria criteria = this.createCriteria(amsOperatorActivity);
		List<AmsOperatorActivity> amsOperatorActivityList = amsOperatorActivityDao.selectByCriteria(criteria);
		return amsOperatorActivityList;
	}
	
	@Override
	public List<AmsOperatorActivity> selectAmsOperatorActivityList(Map<String,Object> paramMap) {
		AmsOperatorActivityCriteria criteria = this.createCriteria(paramMap);
		List<AmsOperatorActivity> amsOperatorActivityList = amsOperatorActivityDao.selectByCriteria(criteria);
		return amsOperatorActivityList;
	}
	
	private AmsOperatorActivityCriteria createCriteria(AmsOperatorActivity amsOperatorActivity) {
		AmsOperatorActivityCriteria criteria = new AmsOperatorActivityCriteria();
		Criteria c = criteria.createCriteria();
		if (amsOperatorActivity != null) {
			if (amsOperatorActivity.getId() != null) {
				c.andIdEqualTo(amsOperatorActivity.getId());
			}	
			if (amsOperatorActivity.getActivityId() != null) {
				c.andActivityIdEqualTo(amsOperatorActivity.getActivityId());
			}	
			if (amsOperatorActivity.getActivityDesc() != null) {
				c.andActivityDescEqualTo(amsOperatorActivity.getActivityDesc());
			}	
			if (amsOperatorActivity.getOperator() != null) {
				c.andOperatorEqualTo(amsOperatorActivity.getOperator());
			}	
			if (amsOperatorActivity.getIsDown() != null) {
				c.andIsDownEqualTo(amsOperatorActivity.getIsDown());
			}	
			if (amsOperatorActivity.getActivityCost() != null) {
				c.andActivityCostEqualTo(amsOperatorActivity.getActivityCost());
			}	
			if (amsOperatorActivity.getActivityRemark() != null) {
				c.andActivityRemarkEqualTo(amsOperatorActivity.getActivityRemark());
			}	
			if (amsOperatorActivity.getCreateName() != null) {
				c.andCreateNameEqualTo(amsOperatorActivity.getCreateName());
			}	
			if (amsOperatorActivity.getCreateDatetime() != null) {
				c.andCreateDatetimeEqualTo(amsOperatorActivity.getCreateDatetime());
			}	
			if (amsOperatorActivity.getUpdateName() != null) {
				c.andUpdateNameEqualTo(amsOperatorActivity.getUpdateName());
			}	
			if (amsOperatorActivity.getUpdateDatetime() != null) {
				c.andUpdateDatetimeEqualTo(amsOperatorActivity.getUpdateDatetime());
			}	
		}
		return criteria;
	}
	
	private AmsOperatorActivityCriteria createCriteria(Map<String, Object> paramMap) {
		AmsOperatorActivityCriteria criteria = new AmsOperatorActivityCriteria();
		Criteria c = criteria.createCriteria();
		if (paramMap != null) {
			if (paramMap.get("id") != null) {
				c.andIdEqualTo((String) paramMap.get("id"));
			}
			if (paramMap.get("activityId") != null) {
				c.andActivityIdEqualTo((String) paramMap.get("activityId"));
			}
			if (paramMap.get("activityDesc") != null) {
				c.andActivityDescEqualTo((String) paramMap.get("activityDesc"));
			}
			if (paramMap.get("operator") != null) {
				c.andOperatorEqualTo((String) paramMap.get("operator"));
			}
			if (paramMap.get("isDown") != null) {
				c.andIsDownEqualTo((Boolean) paramMap.get("isDown"));
			}
			if (paramMap.get("activityCost") != null) {
				c.andActivityCostEqualTo((BigDecimal) paramMap.get("activityCost"));
			}
			if (paramMap.get("activityRemark") != null) {
				c.andActivityRemarkEqualTo((String) paramMap.get("activityRemark"));
			}
			if (paramMap.get("createName") != null) {
				c.andCreateNameEqualTo((String) paramMap.get("createName"));
			}
			if (paramMap.get("createDatetime") != null) {
				c.andCreateDatetimeEqualTo((Timestamp) paramMap.get("createDatetime"));
			}
			if (paramMap.get("updateName") != null) {
				c.andUpdateNameEqualTo((String) paramMap.get("updateName"));
			}
			if (paramMap.get("updateDatetime") != null) {
				c.andUpdateDatetimeEqualTo((Timestamp) paramMap.get("updateDatetime"));
			}
		}
		return criteria;
	}
}

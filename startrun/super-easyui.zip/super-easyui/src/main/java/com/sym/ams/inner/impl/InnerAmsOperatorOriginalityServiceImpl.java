package com.sym.ams.inner.impl;

import java.lang.String;
import java.lang.Boolean;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.sym.ams.domain.AmsOperatorOriginalityCriteria;
import com.sym.ams.domain.AmsOperatorOriginalityCriteria.Criteria;

import com.sym.ams.domain.AmsOperatorOriginality;
import com.sym.ams.dao.AmsOperatorOriginalityDao;
import com.sym.ams.inner.InnerAmsOperatorOriginalityService;

/**
 * 模板引擎生成的实体类
 * @email hncdyj123@163.com
 */
@Service
public class InnerAmsOperatorOriginalityServiceImpl implements InnerAmsOperatorOriginalityService {

	@Resource
	private AmsOperatorOriginalityDao amsOperatorOriginalityDao;
	
	@Override
	public int insertAmsOperatorOriginality(AmsOperatorOriginality amsOperatorOriginality) {
		return amsOperatorOriginalityDao.insert(amsOperatorOriginality);
	}

	@Override
	public int insertAmsOperatorOriginalitySelective(AmsOperatorOriginality amsOperatorOriginality) {
		return amsOperatorOriginalityDao.insertSelective(amsOperatorOriginality);
	}
	
	@Override
	public int deleteAmsOperatorOriginalityByCriteria(AmsOperatorOriginality amsOperatorOriginality) {
		AmsOperatorOriginalityCriteria criteria = this.createCriteria(amsOperatorOriginality);
		return amsOperatorOriginalityDao.deleteByCriteria(criteria);
	}
	
	@Override
	public int deleteAmsOperatorOriginalityByPrimaryKey(String primaryId) {
		return amsOperatorOriginalityDao.deleteByPrimaryKey(primaryId);
	}

	@Override
	public int updateAmsOperatorOriginalityByCriteriaSelective(AmsOperatorOriginality amsOperatorOriginality1, AmsOperatorOriginality amsOperatorOriginality2) {
		AmsOperatorOriginalityCriteria criteria = this.createCriteria(amsOperatorOriginality1);
		return amsOperatorOriginalityDao.updateByCriteriaSelective(amsOperatorOriginality2,criteria);
	}
	
	@Override
	public int updateAmsOperatorOriginalityByPrimaryKeySelective(AmsOperatorOriginality amsOperatorOriginality) {
		return amsOperatorOriginalityDao.updateByPrimaryKeySelective(amsOperatorOriginality);
	}
	
	@Override
	public int countAmsOperatorOriginalityByCriteria(AmsOperatorOriginality amsOperatorOriginality) {
		AmsOperatorOriginalityCriteria criteria = this.createCriteria(amsOperatorOriginality);
		return amsOperatorOriginalityDao.countByCriteria(criteria);
	}

	@Override
	public AmsOperatorOriginality selectAmsOperatorOriginalityByPrimaryKey(String primaryId) {
		return amsOperatorOriginalityDao.selectByPrimaryKey(primaryId);
	}

	@Override
	public AmsOperatorOriginality selectAmsOperatorOriginality(AmsOperatorOriginality amsOperatorOriginality) {
		AmsOperatorOriginalityCriteria criteria = this.createCriteria(amsOperatorOriginality);
		List<AmsOperatorOriginality> amsOperatorOriginalityList = amsOperatorOriginalityDao.selectByCriteria(criteria);
		if (CollectionUtils.isNotEmpty(amsOperatorOriginalityList)) {
			return amsOperatorOriginalityList.get(0);
		}
		return null;
	}
	
	@Override
	public AmsOperatorOriginality selectAmsOperatorOriginality(Map<String,Object> paramMap) {
		AmsOperatorOriginalityCriteria criteria = this.createCriteria(paramMap);
		List<AmsOperatorOriginality> amsOperatorOriginalityList = amsOperatorOriginalityDao.selectByCriteria(criteria);
		if (CollectionUtils.isNotEmpty(amsOperatorOriginalityList)) {
			return amsOperatorOriginalityList.get(0);
		}
		return null;
	}
	
	@Override
	public List<AmsOperatorOriginality> selectAmsOperatorOriginalityList(AmsOperatorOriginality amsOperatorOriginality) {
		AmsOperatorOriginalityCriteria criteria = this.createCriteria(amsOperatorOriginality);
		List<AmsOperatorOriginality> amsOperatorOriginalityList = amsOperatorOriginalityDao.selectByCriteria(criteria);
		return amsOperatorOriginalityList;
	}
	
	@Override
	public List<AmsOperatorOriginality> selectAmsOperatorOriginalityList(Map<String,Object> paramMap) {
		AmsOperatorOriginalityCriteria criteria = this.createCriteria(paramMap);
		List<AmsOperatorOriginality> amsOperatorOriginalityList = amsOperatorOriginalityDao.selectByCriteria(criteria);
		return amsOperatorOriginalityList;
	}
	
	private AmsOperatorOriginalityCriteria createCriteria(AmsOperatorOriginality amsOperatorOriginality) {
		AmsOperatorOriginalityCriteria criteria = new AmsOperatorOriginalityCriteria();
		Criteria c = criteria.createCriteria();
		if (amsOperatorOriginality != null) {
			if (amsOperatorOriginality.getId() != null) {
				c.andIdEqualTo(amsOperatorOriginality.getId());
			}	
			if (amsOperatorOriginality.getOriginalityId() != null) {
				c.andOriginalityIdEqualTo(amsOperatorOriginality.getOriginalityId());
			}	
			if (amsOperatorOriginality.getOriginalityDesc() != null) {
				c.andOriginalityDescEqualTo(amsOperatorOriginality.getOriginalityDesc());
			}	
			if (amsOperatorOriginality.getPaintFlag() != null) {
				c.andPaintFlagEqualTo(amsOperatorOriginality.getPaintFlag());
			}	
			if (amsOperatorOriginality.getOperator() != null) {
				c.andOperatorEqualTo(amsOperatorOriginality.getOperator());
			}	
			if (amsOperatorOriginality.getIsDown() != null) {
				c.andIsDownEqualTo(amsOperatorOriginality.getIsDown());
			}	
			if (amsOperatorOriginality.getCreateName() != null) {
				c.andCreateNameEqualTo(amsOperatorOriginality.getCreateName());
			}	
			if (amsOperatorOriginality.getCreateDatetime() != null) {
				c.andCreateDatetimeEqualTo(amsOperatorOriginality.getCreateDatetime());
			}	
			if (amsOperatorOriginality.getUpdateName() != null) {
				c.andUpdateNameEqualTo(amsOperatorOriginality.getUpdateName());
			}	
			if (amsOperatorOriginality.getUpdateDatetime() != null) {
				c.andUpdateDatetimeEqualTo(amsOperatorOriginality.getUpdateDatetime());
			}	
		}
		return criteria;
	}
	
	private AmsOperatorOriginalityCriteria createCriteria(Map<String, Object> paramMap) {
		AmsOperatorOriginalityCriteria criteria = new AmsOperatorOriginalityCriteria();
		Criteria c = criteria.createCriteria();
		if (paramMap != null) {
			if (paramMap.get("id") != null) {
				c.andIdEqualTo((String) paramMap.get("id"));
			}
			if (paramMap.get("originalityId") != null) {
				c.andOriginalityIdEqualTo((String) paramMap.get("originalityId"));
			}
			if (paramMap.get("originalityDesc") != null) {
				c.andOriginalityDescEqualTo((String) paramMap.get("originalityDesc"));
			}
			if (paramMap.get("paintFlag") != null) {
				c.andPaintFlagEqualTo((Boolean) paramMap.get("paintFlag"));
			}
			if (paramMap.get("operator") != null) {
				c.andOperatorEqualTo((String) paramMap.get("operator"));
			}
			if (paramMap.get("isDown") != null) {
				c.andIsDownEqualTo((Boolean) paramMap.get("isDown"));
			}
			if (paramMap.get("createName") != null) {
				c.andCreateNameEqualTo((String) paramMap.get("createName"));
			}
			if (paramMap.get("createDatetime") != null) {
				c.andCreateDatetimeEqualTo((Timestamp) paramMap.get("createDatetime"));
			}
			if (paramMap.get("updateName") != null) {
				c.andUpdateNameEqualTo((String) paramMap.get("updateName"));
			}
			if (paramMap.get("updateDatetime") != null) {
				c.andUpdateDatetimeEqualTo((Timestamp) paramMap.get("updateDatetime"));
			}
		}
		return criteria;
	}
}

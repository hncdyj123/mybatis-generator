package com.sym.ams.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sym.ams.domain.base.*;
import com.sym.ams.domain.AmsOperatorChannel;
import com.sym.ams.service.AmsOperatorChannelService;

@Controller
@RequestMapping("/amsOperatorChannel")
public class AmsOperatorChannelController {
	private static Logger LOGGER = LoggerFactory.getLogger(AmsOperatorChannel.class);
	@Resource
	private AmsOperatorChannelService amsOperatorChannelService;

	@RequestMapping(value = "init")
	public ModelAndView init(HttpServletRequest request) {
		ModelAndView model = new ModelAndView();
		model.setViewName("/amsOperatorChannel");
		return model;
	}

	@RequestMapping(value = "getDataGrid", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object getDataGrid(AmsOperatorChannel amsOperatorChannel) {
		DataGrid dataGrid = new DataGrid();
		try {
			dataGrid = amsOperatorChannelService.queryAmsOperatorChannelByPage(amsOperatorChannel);
		} catch (Exception e) {
			LOGGER.error("getDataGrid method error : " + e);
			dataGrid.setCode(500);
			dataGrid.setMessage("getDataGrid error!");
		}
		return dataGrid;
	}

	@RequestMapping(value = "insert", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object insert(AmsOperatorChannel amsOperatorChannel) {
		Message message = new Message();
		try {
			amsOperatorChannelService.insertAmsOperatorChannelSelective(amsOperatorChannel);
		} catch (Exception e) {
			LOGGER.error("insert method error :", e);
			message.setCode(500);
			message.setMessage("insert error!");
		}
		return message;
	}
	
	@RequestMapping(value = "delete", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object delete(AmsOperatorChannel amsOperatorChannel) {
		Message message = new Message();
		try {
			amsOperatorChannelService.deleteAmsOperatorChannelByPrimaryKey(amsOperatorChannel.getId());
		} catch (Exception e) {
			LOGGER.error("delete method error :", e);
			message.setCode(500);
			message.setMessage("delete error!");
		}
		return message;
	}

	@RequestMapping(value = "update", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object update(AmsOperatorChannel amsOperatorChannel) {
		Message message = new Message();
		try {
			amsOperatorChannelService.updateAmsOperatorChannelByPrimaryKeySelective(amsOperatorChannel);
		} catch (Exception e) {
			LOGGER.error("update method error :", e);
			message.setCode(500);
			message.setMessage("update error!");
		}
		return message;
	}

	@RequestMapping(value = "query", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object query(AmsOperatorChannel amsOperatorChannel) {
		Message message = new Message();
		try {
			message.setResult(amsOperatorChannelService.selectAmsOperatorChannelList(amsOperatorChannel));
		} catch (Exception e) {
			LOGGER.error("query method error :", e);
			message.setCode(500);
			message.setMessage("query error!");
		}
		return message;
	}
	
	@RequestMapping(value = "queryById", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object queryById(AmsOperatorChannel amsOperatorChannel) {
		Message message = new Message();
		try {
			message.setResult(amsOperatorChannelService.selectAmsOperatorChannelByPrimaryKey(amsOperatorChannel.getId()));
		} catch (Exception e) {
			LOGGER.error("queryById method error :", e);
			message.setCode(500);
			message.setMessage("queryById error!");
		}
		return message;
	}
	
	@RequestMapping(value = "queryByCondition", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Object queryByCondition(AmsOperatorChannel amsOperatorChannel) {
		Message message = new Message();
		try {
			message.setResult(amsOperatorChannelService.selectAmsOperatorChannelList(amsOperatorChannel));
		} catch (Exception e) {
			LOGGER.error("queryByCondition method error :", e);
			message.setCode(500);
			message.setMessage("queryByCondition error!");
		}
		return message;
	}

}
